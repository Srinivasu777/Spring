package com.fis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootIntroApplicationTests {

	@Test
	void contextLoads() {
	}

}
